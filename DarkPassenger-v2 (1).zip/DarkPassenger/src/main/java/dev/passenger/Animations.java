package dev.passenger;

import org.bukkit.Bukkit;
import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.Display;
import org.bukkit.entity.ItemDisplay;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.util.Transformation;
import org.bukkit.util.Vector;
import org.joml.Quaternionf;
import org.joml.Vector3f;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Visual animations built from ItemDisplay entities (client-side interpolation, no resource pack required).
 * The item sprite is assumed to be drawn like a sword: handle bottom-left, tip top-right.
 */
public final class Animations {
    /** Distance from the sprite centre to its tip, in sprite units (NONE transform: a flat item is exactly 1 block wide). */
    private static final float TIP = 0.44f;

    private final PassengerPlugin plugin;
    private final Set<ItemDisplay> active = new HashSet<>();

    public Animations(PassengerPlugin plugin) {
        this.plugin = plugin;
    }

    public boolean enabled() {
        return plugin.getConfig().getBoolean("animations.enabled", true);
    }

    public void removeAll() {
        for (ItemDisplay d : new ArrayList<>(active)) d.remove();
        active.clear();
    }

    // ------------------------------------------------------------------ helpers

    /** Transformation that puts the item's TIP at tipRel (relative to the display entity position). */
    private Transformation pose(Quaternionf q, float scale, Vector3f tipRel) {
        Vector3f tipOffset = new Vector3f(TIP * scale, TIP * scale, 0f).rotate(q);
        Vector3f translation = new Vector3f(tipRel).sub(tipOffset);
        return new Transformation(translation, new Quaternionf(q), new Vector3f(scale, scale, scale), new Quaternionf());
    }

    private ItemDisplay spawn(Location at, ItemStack stack, Transformation initial) {
        Location l = at.clone();
        l.setYaw(0f);
        l.setPitch(0f);
        ItemDisplay d = l.getWorld().spawn(l, ItemDisplay.class, e -> {
            e.setItemStack(stack);
            e.setItemDisplayTransform(ItemDisplay.ItemDisplayTransform.NONE);
            e.setBrightness(new Display.Brightness(15, 15));
            e.setPersistent(false);
            e.setTransformation(initial);
        });
        active.add(d);
        return d;
    }

    private void moveTo(ItemDisplay d, Transformation tr, int ticks) {
        if (!d.isValid()) return;
        d.setInterpolationDelay(0);
        d.setInterpolationDuration(ticks);
        d.setTransformation(tr);
    }

    private void remove(ItemDisplay d) {
        d.remove();
        active.remove(d);
    }

    private void later(long ticks, Runnable r) {
        Bukkit.getScheduler().runTaskLater(plugin, r, ticks);
    }

    /** Horizontal unit vector from the dexter towards the target. */
    private Vector dirTo(Player from, LivingEntity to) {
        Vector v = to.getLocation().toVector().subtract(from.getLocation().toVector());
        v.setY(0);
        if (v.lengthSquared() < 1.0e-4) {
            v = from.getLocation().getDirection();
            v.setY(0);
        }
        if (v.lengthSquared() < 1.0e-4) v = new Vector(1, 0, 0);
        return v.normalize();
    }

    // ------------------------------------------------------------------ syringe

    /** Syringe goes into the neck from the dexter's side, stays a moment, then is pulled out. */
    public void syringe(Player dexter, LivingEntity target, ItemStack model, Runnable onImpact) {
        Location neck = target.getEyeLocation().subtract(0, 0.3, 0);
        Vector d = dirTo(dexter, target);
        float yaw = (float) Math.atan2(-d.getZ(), d.getX());
        Quaternionf q = new Quaternionf().rotateY(yaw).rotateZ((float) (-Math.PI / 4));
        float scale = (float) plugin.getConfig().getDouble("animations.syringe-scale", 0.55);
        Vector3f far = new Vector3f((float) (-d.getX() * 0.9), 0f, (float) (-d.getZ() * 0.9));
        Vector3f near = new Vector3f((float) (-d.getX() * 0.12), 0f, (float) (-d.getZ() * 0.12));

        ItemDisplay disp = spawn(neck, model, pose(q, scale, far));
        later(2, () -> {
            if (dexter.isOnline()) dexter.swingMainHand();
            moveTo(disp, pose(q, scale, near), 4);
        });
        later(6, () -> {
            neck.getWorld().playSound(neck, Sound.ENTITY_ARROW_HIT_PLAYER, 1f, 0.8f);
            neck.getWorld().spawnParticle(Particle.CRIT, neck, 6, 0.1, 0.1, 0.1, 0.1);
            onImpact.run();
        });
        later(16, () -> moveTo(disp, pose(q, scale, far), 5));
        later(23, () -> remove(disp));
    }

    // ------------------------------------------------------------------ knife

    /** Knife is raised and driven down into the chest several times; onFinish runs on the last stab. */
    public void knife(Player dexter, LivingEntity target, ItemStack model, Runnable onFinish, Runnable onAbort) {
        int stabs = Math.max(1, plugin.getConfig().getInt("animations.knife-stabs", 3));
        float scale = (float) plugin.getConfig().getDouble("animations.knife-scale", 0.7);
        Location chest = target.getLocation().add(0, target.getHeight() * 0.62, 0);
        Vector d = dirTo(dexter, target);
        float yaw = (float) Math.atan2(-d.getZ(), d.getX());
        Quaternionf q = new Quaternionf().rotateY(yaw).rotateZ((float) (-3 * Math.PI / 4));
        float fx = (float) (-d.getX() * 0.2);
        float fz = (float) (-d.getZ() * 0.2);
        Vector3f raised = new Vector3f(fx, 0.75f, fz);
        Vector3f down = new Vector3f(fx, 0.0f, fz);

        ItemDisplay disp = spawn(chest, model, pose(q, scale, raised));
        AtomicBoolean aborted = new AtomicBoolean(false);

        long t = 4;
        for (int i = 0; i < stabs; i++) {
            final boolean last = i == stabs - 1;
            guarded(t, dexter, target, disp, aborted, onAbort, () -> {
                dexter.swingMainHand();
                moveTo(disp, pose(q, scale, down), 2);
            });
            guarded(t + 2, dexter, target, disp, aborted, onAbort, () -> {
                chest.getWorld().playSound(chest, Sound.ENTITY_PLAYER_ATTACK_CRIT, 1f, 0.7f);
                chest.getWorld().spawnParticle(Particle.DUST, chest, 12, 0.15, 0.15, 0.15, 0,
                        new Particle.DustOptions(Color.fromRGB(150, 0, 0), 1.3f));
                if (last) onFinish.run();
            });
            if (!last) {
                guarded(t + 4, dexter, target, disp, aborted, onAbort, () -> moveTo(disp, pose(q, scale, raised), 3));
            }
            t += 8;
        }
        later(t + 8, () -> remove(disp));
    }

    /** Runs a step only if the scene is still valid; otherwise aborts the whole animation once. */
    private void guarded(long delay, Player dexter, LivingEntity target, ItemDisplay disp,
                         AtomicBoolean aborted, Runnable onAbort, Runnable step) {
        later(delay, () -> {
            if (aborted.get()) return;
            ControlManager.Control c = plugin.control().get(target.getUniqueId());
            boolean ok = dexter.isOnline() && target.isValid()
                    && dexter.getWorld().equals(target.getWorld())
                    && dexter.getLocation().distanceSquared(target.getLocation()) <= 64
                    && c != null && c.state == ControlManager.State.BOUND;
            if (!ok) {
                aborted.set(true);
                remove(disp);
                onAbort.run();
                return;
            }
            step.run();
        });
    }
}
