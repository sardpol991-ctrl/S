package dev.passenger;

import org.bukkit.Bukkit;
import org.bukkit.command.PluginCommand;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;

public final class PassengerPlugin extends JavaPlugin {

    public enum Mode { PVP, PVE, BOTH }

    private Messages messages;
    private ItemFactory items;
    private DataManager data;
    private StainManager stains;
    private ControlManager control;
    private CodeOfHarry code;
    private PassengerTask passenger;
    private RitualManager ritual;
    private SlidesGui slidesGui;
    private Animations animations;
    private final Map<String, Long> cooldowns = new HashMap<>();

    @Override
    public void onEnable() {
        saveDefaultConfig();
        messages = new Messages(this);
        messages.load();
        items = new ItemFactory(this);
        data = new DataManager(this);
        data.load();
        stains = new StainManager(this);
        stains.load();
        control = new ControlManager(this);
        code = new CodeOfHarry(this);
        passenger = new PassengerTask(this);
        ritual = new RitualManager(this);
        slidesGui = new SlidesGui(this);
        animations = new Animations(this);

        Bukkit.getPluginManager().registerEvents(new DexterListener(this), this);
        Bukkit.getPluginManager().registerEvents(new ControlListener(this), this);
        Bukkit.getPluginManager().registerEvents(slidesGui, this);

        PluginCommand cmd = getCommand("dexter");
        if (cmd != null) {
            DexterCommand dc = new DexterCommand(this);
            cmd.setExecutor(dc);
            cmd.setTabCompleter(dc);
        }

        getLogger().info("DarkPassenger " + getPluginMeta().getVersion() + " | animations: "
                + animations.enabled() + " | custom models: "
                + getConfig().getBoolean("items.use-custom-models", false));

        Bukkit.getScheduler().runTaskTimer(this, passenger::tick, 20L, 20L);
        Bukkit.getScheduler().runTaskTimer(this, control::tick, 10L, 10L);
        Bukkit.getScheduler().runTaskTimer(this, () -> {
            data.save();
            stains.save();
        }, 6000L, 6000L);
    }

    @Override
    public void onDisable() {
        if (animations != null) animations.removeAll();
        if (control != null) control.releaseAll();
        if (passenger != null) passenger.hideAll();
        if (data != null) data.save();
        if (stains != null) stains.save();
    }

    public void reloadAll() {
        reloadConfig();
        messages.load();
    }

    public Messages messages() { return messages; }
    public ItemFactory items() { return items; }
    public DataManager data() { return data; }
    public StainManager stains() { return stains; }
    public ControlManager control() { return control; }
    public CodeOfHarry code() { return code; }
    public PassengerTask passenger() { return passenger; }
    public RitualManager ritual() { return ritual; }
    public SlidesGui slidesGui() { return slidesGui; }
    public Animations animations() { return animations; }

    public Mode mode() {
        try {
            return Mode.valueOf(getConfig().getString("mode", "BOTH").toUpperCase(Locale.ROOT));
        } catch (IllegalArgumentException ex) {
            return Mode.BOTH;
        }
    }

    public boolean allowsPlayers() { return mode() != Mode.PVE; }
    public boolean allowsMobs() { return mode() != Mode.PVP; }

    public boolean isDexter(Player p) {
        return data.get(p.getUniqueId()).dexter || p.hasPermission("dexter.role");
    }

    /** Returns remaining seconds if on cooldown, otherwise starts the cooldown and returns 0. */
    public long tryCooldown(UUID id, String key, int seconds) {
        String k = id + ":" + key;
        long now = System.currentTimeMillis();
        Long until = cooldowns.get(k);
        if (until != null && until > now) {
            return (until - now + 999) / 1000;
        }
        cooldowns.put(k, now + seconds * 1000L);
        return 0;
    }

    public void giveItem(Player p, ItemStack stack) {
        Map<Integer, ItemStack> left = p.getInventory().addItem(stack);
        for (ItemStack rest : left.values()) {
            p.getWorld().dropItemNaturally(p.getLocation(), rest);
        }
    }
}
