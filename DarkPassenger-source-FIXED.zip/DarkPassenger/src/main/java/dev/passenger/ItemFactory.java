package dev.passenger;

import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;

import java.text.SimpleDateFormat;
import java.util.Date;

public final class ItemFactory {
    private final PassengerPlugin plugin;
    private final NamespacedKey typeKey;
    private final NamespacedKey victimKey;

    public ItemFactory(PassengerPlugin plugin) {
        this.plugin = plugin;
        this.typeKey = new NamespacedKey(plugin, "item_type");
        this.victimKey = new NamespacedKey(plugin, "victim");
    }

    private Material material(String path, Material def) {
        Material m = Material.matchMaterial(plugin.getConfig().getString(path, def.name()));
        return (m != null && m.isItem()) ? m : def;
    }

    private void applyModel(ItemMeta meta, ItemType type) {
        if (!plugin.getConfig().getBoolean("items.use-custom-models", true)) return;
        if (type != ItemType.KNIFE && type != ItemType.SYRINGE) return;
        NamespacedKey key = NamespacedKey.fromString("darkpassenger:" + type.key);
        if (key != null) meta.setItemModel(key);
    }

    /** Plain stack used as the visible item of animations (carries the custom model when enabled). */
    public ItemStack displayStack(ItemType type) {
        ItemStack stack = new ItemStack(material("items." + type.key + ".material", type.def));
        ItemMeta meta = stack.getItemMeta();
        applyModel(meta, type);
        stack.setItemMeta(meta);
        return stack;
    }

    public ItemStack create(ItemType type, int amount, String victim) {
        ItemStack stack = new ItemStack(material("items." + type.key + ".material", type.def), Math.max(1, amount));
        ItemMeta meta = stack.getItemMeta();
        Messages m = plugin.messages();
        meta.displayName(m.component("items." + type.key + ".name").decoration(TextDecoration.ITALIC, false));
        meta.lore(m.list("items." + type.key + ".lore", "victim", victim == null ? "?" : victim));
        if (type == ItemType.KNIFE) meta.setUnbreakable(true);
        applyModel(meta, type);
        PersistentDataContainer pdc = meta.getPersistentDataContainer();
        pdc.set(typeKey, PersistentDataType.STRING, type.key);
        if (victim != null) pdc.set(victimKey, PersistentDataType.STRING, victim);
        stack.setItemMeta(meta);
        return stack;
    }

    public ItemType typeOf(ItemStack stack) {
        if (stack == null || !stack.hasItemMeta()) return null;
        String s = stack.getItemMeta().getPersistentDataContainer().get(typeKey, PersistentDataType.STRING);
        return s == null ? null : ItemType.fromKey(s);
    }

    public ItemStack slideItem(PlayerData.Slide s, int index) {
        Material mat = s.justified()
                ? material("items.slide.material", Material.RED_DYE)
                : material("items.slide.material-innocent", Material.GRAY_DYE);
        ItemStack stack = new ItemStack(mat);
        ItemMeta meta = stack.getItemMeta();
        Messages m = plugin.messages();
        String date = new SimpleDateFormat("yyyy-MM-dd HH:mm").format(new Date(s.time()));
        meta.displayName(m.component("items.slide.name", "index", String.valueOf(index), "victim", s.victim())
                .decoration(TextDecoration.ITALIC, false));
        meta.lore(m.list(s.justified() ? "items.slide.lore-justified" : "items.slide.lore-innocent",
                "victim", s.victim(), "date", date));
        stack.setItemMeta(meta);
        return stack;
    }
}
