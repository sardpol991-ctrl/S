# DarkPassenger

Плагин для Purpur/Paper 1.21.11 (Java 21) в духе сериала про Декстера Моргана: Тёмный Пассажир, Кодекс Гарри, транквилизатор, плёнка, ритуал, слайды, следы крови.

## Как собрать .jar

**Вариант 1. GitHub Actions (ничего не нужно ставить)**
1. Создайте репозиторий на github.com и загрузите в него все файлы проекта (включая папку `.github`).
2. Откройте вкладку **Actions** -> workflow **Build plugin** (запускается сам после загрузки, либо кнопкой Run workflow).
3. Когда сборка станет зелёной, откройте её и скачайте **Artifacts -> DarkPassenger** (внутри будет `.jar`).

**Вариант 2. IntelliJ IDEA Community**
1. File -> Open -> выберите папку проекта (там, где `pom.xml`). Подтвердите импорт Maven-проекта.
2. File -> Project Structure -> SDK: JDK 21 (IDE умеет скачать его сама).
3. Справа вкладка **Maven** -> Lifecycle -> **package**. Jar появится в `target/`.

**Вариант 3. Командная строка**
Нужны JDK 21 и Maven: `mvn clean package`. Jar: `target/DarkPassenger-1.0.0.jar`.

## Установка
Положите jar в `plugins/` сервера и перезапустите. Настройки: `plugins/DarkPassenger/config.yml`, тексты: `plugins/DarkPassenger/lang/ru.yml` и `en.yml`.

## Быстрый старт
1. `/dexter set <ник>` - дать роль (или выдайте право `dexter.role` группе в LuckPerms).
2. `/dexter kit <ник>` - выдать все предметы.
3. Цикл: **транквилизатор** (ПКМ по цели) -> **плёнка** (ПКМ по спящей цели) -> **ритуальный нож** (ПКМ по обездвиженной цели).
4. Кодекс решает, виновна ли цель: виновный даёт слайд, награду и снижает шкалу; невиновный даёт штраф.
5. За убитого игрока выдаётся **мешок**: ПКМ в лодке над водой глубиной от 8 блоков убирает улики.
6. Следы крови остаются на месте убийства. Полиция (`dexter.police`) видит их **люминолом**, Декстер стирает **чистящим набором**.

## Режимы (config.yml -> mode)
- `PVP` - целями могут быть только игроки. Виновен тот, кто помечен `/dexter mark` или совершил N убийств игроков за заданное время.
- `PVE` - целями могут быть только мобы. Виновны враждебные мобы из списка, невиновны жители, големы и прирученные питомцы.
- `BOTH` - и то и другое.

## Команды
| Команда | Право |
|---|---|
| `/dexter slides [игрок]` | все (чужие - admin) |
| `/dexter stats [игрок]` | все (чужие - admin) |
| `/dexter check <игрок>` | Декстер или admin |
| `/dexter mark / unmark <игрок>` | dexter.police |
| `/dexter set / unset <игрок>` | dexter.admin |
| `/dexter give <игрок> <предмет> [кол-во]` | dexter.admin |
| `/dexter kit [игрок]` | dexter.admin |
| `/dexter meter <игрок> <значение>` | dexter.admin |
| `/dexter reload` | dexter.admin |

Предметы: `syringe`, `wrap`, `knife`, `bag`, `luminol`, `cleaner`.

## Права
`dexter.admin` (op), `dexter.police` (op), `dexter.role` (роль Декстера без команды), `dexter.immune` (нельзя усыпить).

## Награды и достижения
В `config.yml` в `rewards.*.commands` можно указать команды консоли (`%player%`, `%victim%`), например выдачу предметов, денег или титулов. В `rewards.milestones` - команды при достижении N оправданных слайдов.

## Анимации
- **Шприц**: игла входит в шею цели, держится секунду и вынимается. Усыпление срабатывает в момент укола.
- **Нож**: поднимается над целью и несколько раз опускается в грудь (`animations.knife-stabs`), ритуал завершается на последнем ударе.
- Анимации сделаны на `ItemDisplay`, ресурспак для них не обязателен. Отключить: `animations.enabled: false`.
- Угол и положение предмета при необходимости подстраиваются в классе `Animations` (константа `TIP` и позиции `far`, `near`, `raised`, `down`).

## Ресурспак (свои текстуры ножа и шприца)
Файл `DarkPassenger-ResourcePack.zip` (формат для 1.21.11) даёт предметам ваши текстуры.
1. Выложите zip по прямой ссылке (GitHub Release, Dropbox с `dl=1`, свой хостинг).
2. Посчитайте SHA-1 файла (в Linux: `sha1sum файл.zip`, в Windows: `certutil -hashfile файл.zip SHA1`).
3. В `server.properties` укажите:
```
resource-pack=ССЫЛКА
resource-pack-sha1=ХЭШ
require-resource-pack=true
```
4. В `plugins/DarkPassenger/config.yml` поставьте `items.use-custom-models: true` и сделайте `/dexter reload`. Новые предметы будут с моделью; уже выданные нужно выдать заново.

Без ресурспака оставьте `use-custom-models: false`, тогда предметы выглядят как обычные (блейз-род и железный меч).


## Исправление ресурспака для Java 1.21.11
Используйте `DarkPassenger-ResourcePack-1.21.11-FIXED.zip`: внутри архива `pack.mcmeta` и `assets/` находятся в корне.
В `config.yml` включено `items.use-custom-models: true`. После обновления плагина проверьте эту настройку
в `plugins/DarkPassenger/config.yml`, затем выполните `/dexter reload` и заново выдайте предметы командой `/dexter kit`.
Ресурспак отвечает за текстуры и модели, а плагин назначает предметам `darkpassenger:knife` и `darkpassenger:syringe`.
