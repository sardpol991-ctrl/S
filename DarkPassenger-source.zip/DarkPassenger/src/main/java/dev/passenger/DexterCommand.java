package dev.passenger;

import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.util.StringUtil;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public final class DexterCommand implements CommandExecutor, TabCompleter {
    private final PassengerPlugin plugin;

    public DexterCommand(PassengerPlugin plugin) {
        this.plugin = plugin;
    }

    private boolean admin(CommandSender s) {
        return s.hasPermission("dexter.admin");
    }

    private boolean police(CommandSender s) {
        return s.hasPermission("dexter.police") || admin(s);
    }

    @Override
    public boolean onCommand(CommandSender s, Command cmd, String label, String[] a) {
        if (a.length == 0) {
            help(s);
            return true;
        }
        String sub = a[0].toLowerCase(Locale.ROOT);
        switch (sub) {
            case "set", "unset" -> setRole(s, a, sub.equals("set"));
            case "give" -> give(s, a);
            case "kit" -> kit(s, a);
            case "meter" -> meter(s, a);
            case "slides" -> slides(s, a);
            case "stats" -> stats(s, a);
            case "check" -> check(s, a);
            case "mark", "unmark" -> mark(s, a, sub.equals("mark"));
            case "reload" -> reload(s);
            default -> help(s);
        }
        return true;
    }

    private void usage(CommandSender s, String text) {
        plugin.messages().send(s, "usage", "usage", text);
    }

    private Player online(CommandSender s, String name) {
        Player p = Bukkit.getPlayerExact(name);
        if (p == null) plugin.messages().send(s, "player-not-found", "player", name);
        return p;
    }

    private void help(CommandSender s) {
        for (Component c : plugin.messages().list("help.player")) s.sendMessage(c);
        if (admin(s)) {
            for (Component c : plugin.messages().list("help.admin")) s.sendMessage(c);
        }
    }

    private void setRole(CommandSender s, String[] a, boolean on) {
        Messages m = plugin.messages();
        if (!admin(s)) { m.send(s, "no-permission"); return; }
        if (a.length < 2) { usage(s, "/dexter " + a[0] + " <player>"); return; }
        Player t = online(s, a[1]);
        if (t == null) return;
        plugin.data().get(t.getUniqueId()).dexter = on;
        m.send(s, on ? "role.granted" : "role.revoked", "player", t.getName());
        m.send(t, on ? "role.you-granted" : "role.you-revoked");
        if (!on) plugin.passenger().hide(t);
    }

    private void give(CommandSender s, String[] a) {
        Messages m = plugin.messages();
        if (!admin(s)) { m.send(s, "no-permission"); return; }
        if (a.length < 3) { usage(s, "/dexter give <player> <item> [amount]"); return; }
        Player t = online(s, a[1]);
        if (t == null) return;
        ItemType type = ItemType.fromKey(a[2]);
        if (type == null) { m.send(s, "give.unknown", "item", a[2]); return; }
        int amount = 1;
        if (a.length >= 4) {
            try {
                amount = Math.max(1, Math.min(64, Integer.parseInt(a[3])));
            } catch (NumberFormatException ex) {
                usage(s, "/dexter give <player> <item> [amount]");
                return;
            }
        }
        plugin.giveItem(t, plugin.items().create(type, amount, null));
        m.send(s, "give.done", "amount", String.valueOf(amount), "item", type.key, "player", t.getName());
    }

    private void kit(CommandSender s, String[] a) {
        Messages m = plugin.messages();
        if (!admin(s)) { m.send(s, "no-permission"); return; }
        Player t;
        if (a.length >= 2) {
            t = online(s, a[1]);
            if (t == null) return;
        } else if (s instanceof Player p) {
            t = p;
        } else {
            m.send(s, "player-only");
            return;
        }
        for (ItemType type : ItemType.values()) {
            if (type == ItemType.BAG) continue;
            plugin.giveItem(t, plugin.items().create(type, 1, null));
        }
        m.send(s, "kit.done", "player", t.getName());
    }

    private void meter(CommandSender s, String[] a) {
        Messages m = plugin.messages();
        if (!admin(s)) { m.send(s, "no-permission"); return; }
        if (a.length < 3) { usage(s, "/dexter meter <player> <value>"); return; }
        Player t = online(s, a[1]);
        if (t == null) return;
        double v;
        try {
            v = Double.parseDouble(a[2]);
        } catch (NumberFormatException ex) {
            usage(s, "/dexter meter <player> <value>");
            return;
        }
        double max = plugin.getConfig().getDouble("passenger.max", 100.0);
        v = Math.max(0, Math.min(max, v));
        plugin.data().get(t.getUniqueId()).meter = v;
        m.send(s, "meter.set", "player", t.getName(), "value", String.valueOf(v));
    }

    private void slides(CommandSender s, String[] a) {
        Messages m = plugin.messages();
        if (!(s instanceof Player viewer)) { m.send(s, "player-only"); return; }
        Player owner = viewer;
        if (a.length >= 2 && !a[1].equalsIgnoreCase(viewer.getName())) {
            if (!admin(s)) { m.send(s, "no-permission"); return; }
            owner = online(s, a[1]);
            if (owner == null) return;
        }
        plugin.slidesGui().open(viewer, owner.getUniqueId(), owner.getName(), 0);
    }

    private void stats(CommandSender s, String[] a) {
        Messages m = plugin.messages();
        Player t;
        if (a.length >= 2) {
            if (!admin(s) && !(s instanceof Player sp && sp.getName().equalsIgnoreCase(a[1]))) {
                m.send(s, "no-permission");
                return;
            }
            t = online(s, a[1]);
            if (t == null) return;
        } else if (s instanceof Player p) {
            t = p;
        } else {
            m.send(s, "player-only");
            return;
        }
        PlayerData d = plugin.data().get(t.getUniqueId());
        for (Component c : m.list("stats",
                "player", t.getName(),
                "role", m.plain(plugin.isDexter(t) ? "bool-yes" : "bool-no"),
                "meter", String.format(Locale.ROOT, "%.1f", d.meter),
                "justified", String.valueOf(d.justified),
                "innocent", String.valueOf(d.innocent),
                "slides", String.valueOf(d.slides.size()),
                "marked", m.plain(d.marked ? "bool-yes" : "bool-no"))) {
            s.sendMessage(c);
        }
    }

    private void check(CommandSender s, String[] a) {
        Messages m = plugin.messages();
        if (s instanceof Player p && !plugin.isDexter(p) && !admin(s)) { m.send(s, "not-dexter"); return; }
        if (a.length < 2) { usage(s, "/dexter check <player>"); return; }
        Player t = online(s, a[1]);
        if (t == null) return;
        if (!plugin.allowsPlayers()) { m.send(s, "mode.no-players"); return; }
        CodeOfHarry.Verdict v = plugin.code().judge(t);
        String key = v == CodeOfHarry.Verdict.GUILTY ? "check.guilty"
                : v == CodeOfHarry.Verdict.INNOCENT ? "check.innocent" : "check.neutral";
        m.send(s, key, "target", t.getName());
        int kills = plugin.code().recentKills(plugin.data().get(t.getUniqueId()));
        m.send(s, "check.kills", "kills", String.valueOf(kills));
    }

    private void mark(CommandSender s, String[] a, boolean on) {
        Messages m = plugin.messages();
        if (!police(s)) { m.send(s, "no-permission"); return; }
        if (!plugin.allowsPlayers()) { m.send(s, "mark.pve-mode"); return; }
        if (a.length < 2) { usage(s, "/dexter " + a[0] + " <player>"); return; }
        Player t = online(s, a[1]);
        if (t == null) return;
        plugin.data().get(t.getUniqueId()).marked = on;
        m.send(s, on ? "mark.set" : "mark.unset", "player", t.getName());
    }

    private void reload(CommandSender s) {
        if (!admin(s)) { plugin.messages().send(s, "no-permission"); return; }
        plugin.reloadAll();
        plugin.messages().send(s, "reload.done");
    }

    @Override
    public List<String> onTabComplete(CommandSender s, Command c, String alias, String[] a) {
        List<String> out = new ArrayList<>();
        if (a.length == 1) {
            List<String> subs = new ArrayList<>(List.of("help", "slides", "stats", "check"));
            if (police(s)) subs.addAll(List.of("mark", "unmark"));
            if (admin(s)) subs.addAll(List.of("set", "unset", "give", "kit", "meter", "reload"));
            StringUtil.copyPartialMatches(a[0], subs, out);
            return out;
        }
        String sub = a[0].toLowerCase(Locale.ROOT);
        if (a.length == 2 && List.of("set", "unset", "give", "kit", "meter", "slides", "stats", "check", "mark", "unmark").contains(sub)) {
            List<String> names = new ArrayList<>();
            for (Player p : Bukkit.getOnlinePlayers()) names.add(p.getName());
            StringUtil.copyPartialMatches(a[1], names, out);
        } else if (a.length == 3 && sub.equals("give")) {
            List<String> keys = new ArrayList<>();
            for (ItemType t : ItemType.values()) keys.add(t.key);
            StringUtil.copyPartialMatches(a[2], keys, out);
        }
        return out;
    }
}
