package dev.passenger;

import net.kyori.adventure.bossbar.BossBar;
import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.World;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/** Runs every second: updates the Dark Passenger meter, bonuses and boss bar. */
public final class PassengerTask {
    private final PassengerPlugin plugin;
    private final Map<UUID, BossBar> bars = new HashMap<>();
    private final Map<UUID, Long> lastCombat = new HashMap<>();
    private int counter = 0;

    public PassengerTask(PassengerPlugin plugin) {
        this.plugin = plugin;
    }

    private double max() {
        return plugin.getConfig().getDouble("passenger.max", 100.0);
    }

    private double threshold(String key, double def) {
        return plugin.getConfig().getDouble("passenger.thresholds." + key, def);
    }

    public void markCombat(Player p) {
        lastCombat.put(p.getUniqueId(), System.currentTimeMillis());
        addMeter(p, plugin.getConfig().getDouble("passenger.combat-gain", 0.4));
    }

    public void addMeter(Player p, double amount) {
        PlayerData d = plugin.data().get(p.getUniqueId());
        d.meter = Math.max(0, Math.min(max(), d.meter + amount));
    }

    public void tick() {
        FileConfiguration cfg = plugin.getConfig();
        if (++counter % 60 == 0) plugin.stains().purge();
        long now = System.currentTimeMillis();
        for (Player p : Bukkit.getOnlinePlayers()) {
            if (!plugin.isDexter(p)) {
                hide(p);
                continue;
            }
            PlayerData d = plugin.data().get(p.getUniqueId());
            d.meter = Math.max(0, Math.min(max(), d.meter + delta(p, cfg, now)));
            applyEffects(p, d.meter);
            updateBar(p, d.meter, cfg);
        }
    }

    private double delta(Player p, FileConfiguration cfg, long now) {
        World w = p.getWorld();
        double night = cfg.getDouble("passenger.night-gain-per-second", 0.15);
        double decay = cfg.getDouble("passenger.day-decay-per-second", 0.10);
        if (w.getEnvironment() == World.Environment.NETHER || w.getEnvironment() == World.Environment.THE_END) {
            return night * 0.5;
        }
        long t = w.getTime() % 24000L;
        if (t >= 13000L && t < 23000L) return night;
        double d = -decay;
        if (cfg.getBoolean("mask.enabled", true)) {
            Long lc = lastCombat.get(p.getUniqueId());
            long peaceful = cfg.getLong("mask.peaceful-seconds", 120) * 1000L;
            if (lc == null || now - lc > peaceful) {
                d -= cfg.getDouble("mask.extra-decay-per-second", 0.15);
            }
        }
        return d;
    }

    private void applyEffects(Player p, double meter) {
        if (meter >= threshold("night-vision", 25)) add(p, PotionEffectType.NIGHT_VISION, 260, 0);
        if (meter >= threshold("speed", 50)) add(p, PotionEffectType.SPEED, 60, 0);
        if (meter >= threshold("strength", 75)) add(p, PotionEffectType.STRENGTH, 60, 0);
        if (meter >= threshold("frenzy", 95)) {
            add(p, PotionEffectType.STRENGTH, 60, 1);
            add(p, PotionEffectType.HUNGER, 60, 0);
        }
    }

    private void add(Player p, PotionEffectType type, int duration, int amplifier) {
        p.addPotionEffect(new PotionEffect(type, duration, amplifier, false, false, true));
    }

    private void updateBar(Player p, double meter, FileConfiguration cfg) {
        if (!cfg.getBoolean("passenger.bossbar", true)) {
            hide(p);
            return;
        }
        double max = max();
        float progress = (float) Math.max(0, Math.min(1, meter / max));
        boolean frenzy = meter >= threshold("frenzy", 95);
        Component title = plugin.messages().component(
                frenzy ? "bossbar.title-frenzy" : "bossbar.title",
                "percent", String.valueOf(Math.round(meter / max * 100)));
        BossBar.Color color = frenzy ? BossBar.Color.RED : BossBar.Color.PURPLE;
        BossBar bar = bars.get(p.getUniqueId());
        if (bar == null) {
            bar = BossBar.bossBar(title, progress, color, BossBar.Overlay.PROGRESS);
            bars.put(p.getUniqueId(), bar);
            p.showBossBar(bar);
        } else {
            bar.name(title);
            bar.progress(progress);
            bar.color(color);
        }
    }

    public void hide(Player p) {
        BossBar bar = bars.remove(p.getUniqueId());
        if (bar != null) p.hideBossBar(bar);
    }

    public void hideAll() {
        for (Player p : Bukkit.getOnlinePlayers()) hide(p);
    }
}
