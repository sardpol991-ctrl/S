package dev.passenger;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Boat;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;

public final class RitualManager {
    private final PassengerPlugin plugin;
    private final Map<UUID, UUID> pending = new HashMap<>(); // victim -> dexter

    public RitualManager(PassengerPlugin plugin) {
        this.plugin = plugin;
    }

    public UUID takePending(UUID victim) {
        return pending.remove(victim);
    }

    public String nameOf(LivingEntity e) {
        if (e instanceof Player p) return p.getName();
        Component custom = e.customName();
        if (custom != null) return PlainTextComponentSerializer.plainText().serialize(custom);
        String n = e.getType().name().toLowerCase(Locale.ROOT).replace('_', ' ');
        return Character.toUpperCase(n.charAt(0)) + n.substring(1);
    }

    public void begin(Player dexter, LivingEntity victim) {
        UUID vid = victim.getUniqueId();
        plugin.control().release(victim);
        pending.put(vid, dexter.getUniqueId());
        victim.damage(10_000.0, dexter);
        if (!victim.isDead()) {
            pending.remove(vid);
            plugin.messages().send(dexter, "ritual.failed");
        }
    }

    public void complete(Player d, LivingEntity v) {
        Messages m = plugin.messages();
        FileConfiguration cfg = plugin.getConfig();
        PlayerData pd = plugin.data().get(d.getUniqueId());
        CodeOfHarry.Verdict verdict = plugin.code().judge(v);
        String name = nameOf(v);
        double max = cfg.getDouble("passenger.max", 100.0);

        plugin.stains().add(v.getLocation(), cfg.getInt("blood.stain-count", 6));

        switch (verdict) {
            case GUILTY -> {
                pd.justified++;
                pd.slides.add(new PlayerData.Slide(name, System.currentTimeMillis(), true));
                pd.meter = Math.max(0, pd.meter - cfg.getDouble("rewards.justified.meter-reduction", 40));
                int xp = cfg.getInt("rewards.justified.xp", 30);
                if (xp > 0) d.giveExp(xp);
                m.send(d, "ritual.justified", "victim", name);
                runCommands(cfg.getStringList("rewards.justified.commands"), d, name);
                milestone(d, pd, name);
            }
            case INNOCENT -> {
                pd.innocent++;
                pd.slides.add(new PlayerData.Slide(name, System.currentTimeMillis(), false));
                pd.meter = Math.min(max, pd.meter + cfg.getDouble("rewards.innocent.meter-gain", 20));
                int sec = cfg.getInt("rewards.innocent.weakness-seconds", 60);
                if (sec > 0) d.addPotionEffect(new PotionEffect(PotionEffectType.WEAKNESS, sec * 20, 0));
                m.send(d, "ritual.innocent", "victim", name);
                runCommands(cfg.getStringList("rewards.innocent.commands"), d, name);
            }
            case NEUTRAL -> m.send(d, "ritual.neutral", "victim", name);
        }

        // A punished player starts with a clean record.
        if (v instanceof Player vp) {
            PlayerData vd = plugin.data().get(vp.getUniqueId());
            vd.marked = false;
            vd.kills.clear();
        }

        boolean bagAllowed = cfg.getBoolean("bag.enabled", true)
                && (v instanceof Player || cfg.getBoolean("bag.for-mobs", false))
                && verdict != CodeOfHarry.Verdict.NEUTRAL;
        if (bagAllowed) {
            plugin.giveItem(d, plugin.items().create(ItemType.BAG, 1, name));
        }
    }

    private void milestone(Player d, PlayerData pd, String victim) {
        ConfigurationSection ms = plugin.getConfig().getConfigurationSection("rewards.milestones");
        String key = String.valueOf(pd.justified);
        if (ms == null || !ms.contains(key)) return;
        plugin.messages().send(d, "ritual.milestone", "count", key);
        runCommands(ms.getStringList(key), d, victim);
    }

    private void runCommands(List<String> commands, Player d, String victim) {
        for (String c : commands) {
            Bukkit.dispatchCommand(Bukkit.getConsoleSender(),
                    c.replace("%player%", d.getName()).replace("%victim%", victim));
        }
    }

    public void disposeBag(Player p, ItemStack hand) {
        Messages m = plugin.messages();
        FileConfiguration cfg = plugin.getConfig();
        Entity vehicle = p.getVehicle();
        if (!(vehicle instanceof Boat)) {
            m.send(p, "bag.need-boat");
            return;
        }
        int need = cfg.getInt("bag.min-water-depth", 8);
        if (waterDepth(vehicle.getLocation()) < need) {
            m.send(p, "bag.need-depth", "depth", String.valueOf(need));
            return;
        }
        hand.setAmount(hand.getAmount() - 1);
        int xp = cfg.getInt("bag.xp", 20);
        if (xp > 0) p.giveExp(xp);
        PlayerData pd = plugin.data().get(p.getUniqueId());
        pd.meter = Math.max(0, pd.meter - cfg.getDouble("bag.meter-reduction", 10));
        p.getWorld().playSound(p.getLocation(), Sound.ENTITY_PLAYER_SPLASH, 1f, 0.7f);
        m.send(p, "bag.disposed");
    }

    private int waterDepth(Location l) {
        World w = l.getWorld();
        if (w == null) return 0;
        int x = l.getBlockX();
        int z = l.getBlockZ();
        int minY = w.getMinHeight();
        int y = l.getBlockY();
        for (int i = 0; i < 3 && y > minY && w.getBlockAt(x, y, z).getType() != Material.WATER; i++) {
            y--;
        }
        int depth = 0;
        for (int yy = y; yy > minY && depth < 64; yy--) {
            if (w.getBlockAt(x, yy, z).getType() == Material.WATER) depth++;
            else break;
        }
        return depth;
    }
}
