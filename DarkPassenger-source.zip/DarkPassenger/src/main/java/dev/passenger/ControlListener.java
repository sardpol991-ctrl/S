package dev.passenger;

import org.bukkit.Location;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.player.PlayerInteractEntityEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerTeleportEvent;
import org.bukkit.event.world.EntitiesLoadEvent;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;

public final class ControlListener implements Listener {
    private final PassengerPlugin plugin;

    public ControlListener(PassengerPlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler(ignoreCancelled = true)
    public void onMove(PlayerMoveEvent e) {
        if (!e.hasChangedPosition()) return;
        if (!plugin.control().isFrozen(e.getPlayer())) return;
        Location from = e.getFrom();
        Location to = e.getTo();
        if (from.getX() != to.getX() || from.getZ() != to.getZ() || to.getY() > from.getY()) {
            Location fixed = from.clone();
            fixed.setYaw(to.getYaw());
            fixed.setPitch(to.getPitch());
            e.setTo(fixed);
        }
    }

    @EventHandler
    public void onInteract(PlayerInteractEvent e) {
        if (plugin.control().isFrozen(e.getPlayer())) e.setCancelled(true);
    }

    @EventHandler
    public void onInteractEntity(PlayerInteractEntityEvent e) {
        if (plugin.control().isFrozen(e.getPlayer())) e.setCancelled(true);
    }

    @EventHandler
    public void onBreak(BlockBreakEvent e) {
        if (plugin.control().isFrozen(e.getPlayer())) e.setCancelled(true);
    }

    @EventHandler
    public void onPlace(BlockPlaceEvent e) {
        if (plugin.control().isFrozen(e.getPlayer())) e.setCancelled(true);
    }

    @EventHandler
    public void onTeleport(PlayerTeleportEvent e) {
        if (plugin.control().isFrozen(e.getPlayer())) e.setCancelled(true);
    }

    @EventHandler(ignoreCancelled = true)
    public void onDamageBy(EntityDamageByEntityEvent e) {
        if (plugin.control().isFrozen(e.getDamager())) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onDamage(EntityDamageEvent e) {
        if (!(e.getEntity() instanceof LivingEntity le)) return;
        ControlManager.Control c = plugin.control().get(le.getUniqueId());
        if (c == null) return;
        EntityDamageEvent.DamageCause cause = e.getCause();
        if (cause == EntityDamageEvent.DamageCause.VOID
                || cause == EntityDamageEvent.DamageCause.SUICIDE
                || cause == EntityDamageEvent.DamageCause.KILL) {
            return;
        }
        if (c.state == ControlManager.State.BOUND) {
            e.setCancelled(true);
            return;
        }
        if (plugin.getConfig().getBoolean("tranquilizer.wake-on-damage", true)) {
            plugin.control().release(le);
        }
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        plugin.control().release(e.getPlayer());
        plugin.passenger().hide(e.getPlayer());
    }

    /** Restores AI for mobs that were frozen when the chunk unloaded or the server stopped. */
    @EventHandler
    public void onEntitiesLoad(EntitiesLoadEvent e) {
        for (Entity en : e.getEntities()) {
            if (!(en instanceof LivingEntity le)) continue;
            PersistentDataContainer pdc = le.getPersistentDataContainer();
            Byte v = pdc.get(plugin.control().aiKey, PersistentDataType.BYTE);
            if (v != null && !plugin.control().isFrozen(le)) {
                le.setAI(v == 1);
                pdc.remove(plugin.control().aiKey);
            }
        }
    }
}
