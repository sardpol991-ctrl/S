package dev.passenger;

import org.bukkit.Bukkit;
import org.bukkit.NamespacedKey;
import org.bukkit.Particle;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.UUID;

/** Tracks tranquilized and wrapped (bound) entities. */
public final class ControlManager {
    public enum State { TRANQUILIZED, BOUND }

    public static final class Control {
        public State state;
        public long until;
        public UUID dexter;
        public boolean hadAi = true;
    }

    private final PassengerPlugin plugin;
    private final Map<UUID, Control> map = new HashMap<>();
    public final NamespacedKey aiKey;

    public ControlManager(PassengerPlugin plugin) {
        this.plugin = plugin;
        this.aiKey = new NamespacedKey(plugin, "frozen_ai");
    }

    public Control get(UUID id) {
        return map.get(id);
    }

    public boolean isFrozen(Entity e) {
        return map.containsKey(e.getUniqueId());
    }

    public void tranquilize(LivingEntity target, UUID dexter, int seconds) {
        Control c = map.get(target.getUniqueId());
        if (c == null) {
            c = new Control();
            freezeAi(target, c);
            map.put(target.getUniqueId(), c);
        }
        c.state = State.TRANQUILIZED;
        c.until = System.currentTimeMillis() + seconds * 1000L;
        c.dexter = dexter;
        applyEffects(target, seconds);
    }

    public boolean wrap(LivingEntity target, UUID dexter, int seconds) {
        Control c = map.get(target.getUniqueId());
        if (c == null) {
            if (plugin.getConfig().getBoolean("wrap.require-tranquilized", true)) return false;
            c = new Control();
            freezeAi(target, c);
            map.put(target.getUniqueId(), c);
        }
        c.state = State.BOUND;
        c.until = System.currentTimeMillis() + seconds * 1000L;
        c.dexter = dexter;
        applyEffects(target, seconds);
        return true;
    }

    public void release(LivingEntity target) {
        Control c = map.remove(target.getUniqueId());
        if (c != null) restore(target, c);
    }

    private void freezeAi(LivingEntity t, Control c) {
        if (t instanceof Player) return;
        c.hadAi = t.hasAI();
        t.setAI(false);
        t.getPersistentDataContainer().set(aiKey, PersistentDataType.BYTE, (byte) (c.hadAi ? 1 : 0));
    }

    private void applyEffects(LivingEntity t, int seconds) {
        int ticks = seconds * 20 + 40;
        t.addPotionEffect(new PotionEffect(PotionEffectType.BLINDNESS, ticks, 0, false, false, false));
        t.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, ticks, 6, false, false, false));
    }

    private void restore(LivingEntity t, Control c) {
        t.removePotionEffect(PotionEffectType.BLINDNESS);
        t.removePotionEffect(PotionEffectType.SLOWNESS);
        if (!(t instanceof Player)) {
            t.setAI(c.hadAi);
            t.getPersistentDataContainer().remove(aiKey);
        }
    }

    public void tick() {
        long now = System.currentTimeMillis();
        Iterator<Map.Entry<UUID, Control>> it = map.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<UUID, Control> en = it.next();
            Entity e = Bukkit.getEntity(en.getKey());
            if (!(e instanceof LivingEntity le) || !le.isValid()) {
                it.remove();
                continue;
            }
            Control c = en.getValue();
            if (now >= c.until) {
                restore(le, c);
                it.remove();
                continue;
            }
            if (c.state == State.BOUND) {
                le.getWorld().spawnParticle(Particle.CLOUD, le.getLocation().add(0, 1, 0), 3, 0.3, 0.5, 0.3, 0.0);
            }
        }
    }

    public void releaseAll() {
        for (Map.Entry<UUID, Control> en : map.entrySet()) {
            Entity e = Bukkit.getEntity(en.getKey());
            if (e instanceof LivingEntity le) restore(le, en.getValue());
        }
        map.clear();
    }
}
