package dev.passenger;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.text.minimessage.MiniMessage;
import net.kyori.adventure.text.minimessage.tag.resolver.Placeholder;
import net.kyori.adventure.text.minimessage.tag.resolver.TagResolver;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

public final class Messages {
    private final PassengerPlugin plugin;
    private final MiniMessage mm = MiniMessage.miniMessage();
    private FileConfiguration lang = new YamlConfiguration();

    public Messages(PassengerPlugin plugin) {
        this.plugin = plugin;
    }

    public void load() {
        for (String code : new String[]{"ru", "en"}) {
            File f = new File(plugin.getDataFolder(), "lang/" + code + ".yml");
            if (!f.exists()) plugin.saveResource("lang/" + code + ".yml", false);
        }
        String code = plugin.getConfig().getString("language", "ru");
        File f = new File(plugin.getDataFolder(), "lang/" + code + ".yml");
        if (!f.exists()) f = new File(plugin.getDataFolder(), "lang/en.yml");
        lang = YamlConfiguration.loadConfiguration(f);
        try (InputStream in = plugin.getResource("lang/en.yml")) {
            if (in != null) {
                lang.setDefaults(YamlConfiguration.loadConfiguration(new InputStreamReader(in, StandardCharsets.UTF_8)));
            }
        } catch (IOException ignored) {
            // fallback defaults are optional
        }
    }

    private TagResolver resolver(String... pairs) {
        List<TagResolver> list = new ArrayList<>();
        for (int i = 0; i + 1 < pairs.length; i += 2) {
            list.add(Placeholder.unparsed(pairs[i], pairs[i + 1]));
        }
        return TagResolver.resolver(list);
    }

    public Component component(String key, String... pairs) {
        return mm.deserialize(lang.getString(key, key), resolver(pairs));
    }

    public Component prefixed(String key, String... pairs) {
        return mm.deserialize(lang.getString("prefix", "") + lang.getString(key, key), resolver(pairs));
    }

    public List<Component> list(String key, String... pairs) {
        List<Component> out = new ArrayList<>();
        for (String line : lang.getStringList(key)) {
            out.add(mm.deserialize(line, resolver(pairs)).decoration(TextDecoration.ITALIC, false));
        }
        return out;
    }

    public void send(CommandSender to, String key, String... pairs) {
        to.sendMessage(prefixed(key, pairs));
    }

    public String plain(String key) {
        return lang.getString(key, key);
    }
}
