package dev.passenger;

import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Pose;

import java.lang.reflect.Method;

/** Reflection shims for Paper methods whose exact signatures may differ between versions. */
final class Compat {
    private static final Method SET_POSE2 = find(Entity.class, "setPose", Pose.class, boolean.class);
    private static final Method SET_POSE1 = find(Entity.class, "setPose", Pose.class);
    private static final Method GET_BODY_YAW = find(LivingEntity.class, "getBodyYaw");
    private static final Method SET_BODY_YAW = find(LivingEntity.class, "setBodyYaw", float.class);

    private Compat() {
    }

    private static Method find(Class<?> type, String name, Class<?>... params) {
        try {
            return type.getMethod(name, params);
        } catch (NoSuchMethodException ex) {
            return null;
        }
    }

    static void setPose(Entity e, Pose pose, boolean fixed) {
        try {
            if (SET_POSE2 != null) SET_POSE2.invoke(e, pose, fixed);
            else if (SET_POSE1 != null) SET_POSE1.invoke(e, pose);
        } catch (ReflectiveOperationException | RuntimeException ignored) {
            // pose is cosmetic only
        }
    }

    static float bodyYaw(LivingEntity e) {
        try {
            if (GET_BODY_YAW != null) return ((Number) GET_BODY_YAW.invoke(e)).floatValue();
        } catch (ReflectiveOperationException | RuntimeException ignored) {
            // fall back below
        }
        return e.getLocation().getYaw();
    }

    static void setBodyYaw(LivingEntity e, float yaw) {
        try {
            if (SET_BODY_YAW != null) SET_BODY_YAW.invoke(e, yaw);
        } catch (ReflectiveOperationException | RuntimeException ignored) {
            // cosmetic only
        }
    }
}
