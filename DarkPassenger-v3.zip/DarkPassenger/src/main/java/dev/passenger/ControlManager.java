package dev.passenger;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.block.Block;
import org.bukkit.entity.BlockDisplay;
import org.bukkit.entity.Display;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Interaction;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Pose;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.util.Transformation;
import org.bukkit.util.Vector;
import org.joml.Quaternionf;
import org.joml.Vector3f;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.UUID;

/**
 * Tracks tranquilized / wrapped entities: they lie on the ground, can be dragged by the dexter,
 * laid on a plank block, wrapped in film and finally used for the ritual.
 */
public final class ControlManager {
    public enum State { TRANQUILIZED, BOUND }

    public static final class Control {
        public State state;
        public long until;
        public UUID dexter;
        public boolean hadAi = true;
        public boolean lying;
        public float standingHeight = 1.8f;
        public float lieYaw;
        public Location table;          // set when laid on a plank
        public UUID dragger;            // dexter who is dragging right now
        public Interaction proxy;       // invisible big hitbox, because a lying entity has a tiny one
        public BlockDisplay cocoon;     // translucent "film" around the body
    }

    private final PassengerPlugin plugin;
    private final Map<UUID, Control> map = new HashMap<>();
    private final Map<UUID, UUID> proxies = new HashMap<>(); // proxy entity -> victim
    private final Map<UUID, UUID> drags = new HashMap<>();   // dexter -> victim
    private boolean internalMove;
    private int dragCounter;
    public final NamespacedKey aiKey;

    public ControlManager(PassengerPlugin plugin) {
        this.plugin = plugin;
        this.aiKey = new NamespacedKey(plugin, "frozen_ai");
    }

    // ------------------------------------------------------------------ queries

    public Control get(UUID id) {
        return map.get(id);
    }

    public boolean isFrozen(Entity e) {
        return map.containsKey(e.getUniqueId());
    }

    public boolean isInternalMove() {
        return internalMove;
    }

    public boolean isDragging(Player p) {
        return drags.containsKey(p.getUniqueId());
    }

    /** Maps a clicked entity (maybe an invisible hitbox) to the real victim. */
    public LivingEntity resolve(Entity clicked) {
        UUID victim = proxies.get(clicked.getUniqueId());
        if (victim != null) {
            Entity real = Bukkit.getEntity(victim);
            return real instanceof LivingEntity le1 ? le1 : null;
        }
        return clicked instanceof LivingEntity le2 ? le2 : null;
    }

    // ------------------------------------------------------------------ geometry

    private boolean flip() {
        return plugin.getConfig().getBoolean("lying.flip-direction", false);
    }

    /** Horizontal direction from the feet towards the head of a lying body. */
    private Vector headDir(Control c) {
        double r = Math.toRadians(c.lieYaw);
        Vector v = new Vector(-Math.cos(r), 0, Math.sin(r));
        return flip() ? v.multiply(-1) : v;
    }

    private float yawForHead(Vector h) {
        Vector v = flip() ? h.clone().multiply(-1) : h.clone();
        return (float) Math.toDegrees(Math.atan2(v.getZ(), -v.getX()));
    }

    public Vector headVector(LivingEntity e) {
        Control c = map.get(e.getUniqueId());
        if (c == null || !c.lying) return new Vector(0, 0, 1);
        return headDir(c);
    }

    public Location chestOf(LivingEntity e) {
        Control c = map.get(e.getUniqueId());
        Location l = e.getLocation();
        if (c == null || !c.lying) return l.add(0, e.getHeight() * 0.62, 0);
        return l.add(headDir(c).multiply(c.standingHeight * 0.68)).add(0, 0.25, 0);
    }

    public Location neckOf(LivingEntity e) {
        Control c = map.get(e.getUniqueId());
        if (c == null || !c.lying) return e.getEyeLocation().subtract(0, 0.3, 0);
        return e.getLocation().add(headDir(c).multiply(c.standingHeight * 0.88)).add(0, 0.2, 0);
    }

    public Location centerOf(LivingEntity e) {
        Control c = map.get(e.getUniqueId());
        if (c == null || !c.lying) return e.getLocation().add(0, e.getHeight() * 0.5, 0);
        return e.getLocation().add(headDir(c).multiply(c.standingHeight * 0.5)).add(0, 0.2, 0);
    }

    // ------------------------------------------------------------------ state changes

    public void tranquilize(LivingEntity target, UUID dexter, int seconds) {
        Control c = map.get(target.getUniqueId());
        boolean fresh = c == null;
        if (fresh) {
            c = new Control();
            c.standingHeight = (float) target.getHeight();
            freezeAi(target, c);
            map.put(target.getUniqueId(), c);
        }
        c.state = State.TRANQUILIZED;
        c.until = System.currentTimeMillis() + seconds * 1000L;
        c.dexter = dexter;
        applyEffects(target, seconds);
        if (fresh) lieDown(target, c);
    }

    /** Called when the wrapping progress is complete. Victim must already be tranquilized. */
    public boolean wrap(LivingEntity target, UUID dexter, int seconds) {
        Control c = map.get(target.getUniqueId());
        if (c == null) return false;
        c.state = State.BOUND;
        c.until = System.currentTimeMillis() + seconds * 1000L;
        c.dexter = dexter;
        if (c.dragger != null) stopDrag(c.dragger);
        applyEffects(target, seconds);
        spawnCocoon(target, c);
        return true;
    }

    public void release(LivingEntity target) {
        Control c = map.remove(target.getUniqueId());
        if (c != null) restore(target, c);
    }

    private void lieDown(LivingEntity t, Control c) {
        if (!plugin.getConfig().getBoolean("lying.enabled", true)) return;
        c.lying = true;
        c.lieYaw = Compat.bodyYaw(t);
        Compat.setPose(t, Pose.SLEEPING, true);
        Compat.setBodyYaw(t, c.lieYaw);
        ensureProxy(t, c);
    }

    private void freezeAi(LivingEntity t, Control c) {
        if (t instanceof Player) return;
        c.hadAi = t.hasAI();
        t.setAI(false);
        t.getPersistentDataContainer().set(aiKey, PersistentDataType.BYTE, (byte) (c.hadAi ? 1 : 0));
    }

    private void applyEffects(LivingEntity t, int seconds) {
        int ticks = seconds * 20 + 40;
        t.addPotionEffect(new PotionEffect(PotionEffectType.BLINDNESS, ticks, 0, false, false, false));
        t.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, ticks, 6, false, false, false));
    }

    private void restore(LivingEntity t, Control c) {
        t.removePotionEffect(PotionEffectType.BLINDNESS);
        t.removePotionEffect(PotionEffectType.SLOWNESS);
        if (!(t instanceof Player)) {
            t.setAI(c.hadAi);
            t.getPersistentDataContainer().remove(aiKey);
        }
        if (c.lying) Compat.setPose(t, Pose.STANDING, false);
        removeProxy(c);
        removeCocoon(c);
        if (c.dragger != null) {
            drags.remove(c.dragger);
            Player d = Bukkit.getPlayer(c.dragger);
            if (d != null) d.removePotionEffect(PotionEffectType.SLOWNESS);
            c.dragger = null;
        }
    }

    // ------------------------------------------------------------------ proxy hitbox and film

    private void ensureProxy(LivingEntity v, Control c) {
        if (!c.lying) return;
        Location at = centerOf(v);
        at.setY(v.getLocation().getY() - 0.05);
        at.setYaw(0f);
        at.setPitch(0f);
        if (c.proxy == null || !c.proxy.isValid()) {
            c.proxy = v.getWorld().spawn(at, Interaction.class, e -> {
                e.setInteractionWidth(1.5f);
                e.setInteractionHeight(0.8f);
                e.setPersistent(false);
            });
            proxies.put(c.proxy.getUniqueId(), v.getUniqueId());
        } else if (c.proxy.getWorld().equals(at.getWorld()) && c.proxy.getLocation().distanceSquared(at) > 0.04) {
            c.proxy.teleport(at);
        }
    }

    private void removeProxy(Control c) {
        if (c.proxy != null) {
            proxies.remove(c.proxy.getUniqueId());
            c.proxy.remove();
            c.proxy = null;
        }
    }

    private void spawnCocoon(LivingEntity v, Control c) {
        if (!c.lying || c.cocoon != null) return;
        Vector h = headDir(c);
        float length = c.standingHeight + 0.15f;
        float width = 0.9f;
        float height = 0.5f;
        Quaternionf rot = new Quaternionf().rotateY((float) Math.atan2(h.getX(), h.getZ()));
        Vector3f local = new Vector3f(width / 2f, height / 2f, length / 2f).rotate(rot);
        Vector3f center = new Vector3f(
                (float) (h.getX() * c.standingHeight * 0.5), 0.2f, (float) (h.getZ() * c.standingHeight * 0.5));
        Transformation tr = new Transformation(center.sub(local), rot,
                new Vector3f(width, height, length), new Quaternionf());
        Location at = v.getLocation();
        at.setYaw(0f);
        at.setPitch(0f);
        c.cocoon = v.getWorld().spawn(at, BlockDisplay.class, e -> {
            e.setBlock(Material.WHITE_STAINED_GLASS.createBlockData());
            e.setTransformation(tr);
            e.setBrightness(new Display.Brightness(15, 15));
            e.setPersistent(false);
        });
    }

    private void removeCocoon(Control c) {
        if (c.cocoon != null) {
            c.cocoon.remove();
            c.cocoon = null;
        }
    }

    // ------------------------------------------------------------------ dragging and tables

    public void moveSafely(LivingEntity e, Location to) {
        internalMove = true;
        try {
            e.teleport(to);
        } finally {
            internalMove = false;
        }
    }

    public void startDrag(Player dexter, LivingEntity victim) {
        Control c = map.get(victim.getUniqueId());
        if (c == null || c.state != State.TRANQUILIZED) return;
        c.table = null;
        c.dragger = dexter.getUniqueId();
        c.until = Math.max(c.until, System.currentTimeMillis() + 20_000L);
        drags.put(dexter.getUniqueId(), victim.getUniqueId());
    }

    public void stopDrag(UUID dexterId) {
        UUID vid = drags.remove(dexterId);
        if (vid != null) {
            Control c = map.get(vid);
            if (c != null) c.dragger = null;
        }
        Player d = Bukkit.getPlayer(dexterId);
        if (d != null) d.removePotionEffect(PotionEffectType.SLOWNESS);
    }

    /** Puts the dragged victim on top of the given block. */
    public boolean layOnTable(Player dexter, Block block) {
        UUID vid = drags.get(dexter.getUniqueId());
        if (vid == null) return false;
        Entity ve = Bukkit.getEntity(vid);
        Control c = map.get(vid);
        if (!(ve instanceof LivingEntity) || c == null) return false;
        LivingEntity v = (LivingEntity) ve;

        Vector f = dexter.getLocation().getDirection();
        f.setY(0);
        if (f.lengthSquared() < 1.0e-4) f = new Vector(0, 0, 1);
        f.normalize();
        Vector right = new Vector(-f.getZ(), 0, f.getX()); // head towards the dexter's right hand
        c.lieYaw = yawForHead(right);

        double top = block.getBoundingBox().getMaxY();
        Location pos = new Location(block.getWorld(), block.getX() + 0.5, top, block.getZ() + 0.5);
        pos.subtract(right.clone().multiply(0.35));
        pos.setYaw(c.lieYaw);
        pos.setPitch(0f);
        moveSafely(v, pos);
        Compat.setBodyYaw(v, c.lieYaw);

        stopDrag(dexter.getUniqueId());
        c.table = block.getLocation();
        c.until = Math.max(c.until, System.currentTimeMillis()
                + plugin.getConfig().getInt("tranquilizer.sleep-seconds", 60) * 1000L);
        ensureProxy(v, c);
        return true;
    }

    /** Runs every 2 ticks: victims follow the dexter who drags them. */
    public void dragTick() {
        if (drags.isEmpty()) return;
        boolean refresh = ++dragCounter % 5 == 0;
        double maxDist = plugin.getConfig().getDouble("drag.max-distance", 6.0) + 4.0;
        boolean slow = plugin.getConfig().getBoolean("drag.slowness", true);
        Iterator<Map.Entry<UUID, UUID>> it = drags.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<UUID, UUID> en = it.next();
            Player d = Bukkit.getPlayer(en.getKey());
            Entity ve = Bukkit.getEntity(en.getValue());
            Control c = map.get(en.getValue());
            boolean ok = d != null && !d.isDead() && ve instanceof LivingEntity && c != null
                    && c.state == State.TRANQUILIZED && d.getWorld().equals(ve.getWorld())
                    && d.getLocation().distanceSquared(ve.getLocation()) <= maxDist * maxDist;
            if (!ok) {
                if (c != null) c.dragger = null;
                if (d != null) d.removePotionEffect(PotionEffectType.SLOWNESS);
                it.remove();
                continue;
            }
            LivingEntity v = (LivingEntity) ve;
            Vector f = d.getLocation().getDirection();
            f.setY(0);
            if (f.lengthSquared() < 1.0e-4) f = new Vector(0, 0, 1);
            f.normalize();
            double back = c.standingHeight * 0.95 + 0.25;
            Location to = d.getLocation().subtract(f.clone().multiply(back));
            c.lieYaw = yawForHead(f); // head towards the dexter: dragged by the arms
            to.setYaw(c.lieYaw);
            to.setPitch(0f);
            moveSafely(v, to);
            Compat.setBodyYaw(v, c.lieYaw);
            ensureProxy(v, c);
            c.until = Math.max(c.until, System.currentTimeMillis() + 20_000L);
            if (refresh && slow) {
                d.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, 30, 1, false, false, false));
            }
        }
    }

    // ------------------------------------------------------------------ periodic maintenance

    public void tick() {
        long now = System.currentTimeMillis();
        Iterator<Map.Entry<UUID, Control>> it = map.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<UUID, Control> en = it.next();
            Control c = en.getValue();
            Entity e = Bukkit.getEntity(en.getKey());
            if (!(e instanceof LivingEntity) || !e.isValid()) {
                removeProxy(c);
                removeCocoon(c);
                if (c.dragger != null) drags.remove(c.dragger);
                it.remove();
                continue;
            }
            LivingEntity le = (LivingEntity) e;
            if (now >= c.until) {
                restore(le, c);
                it.remove();
                continue;
            }
            applyEffects(le, (int) ((c.until - now) / 1000L) + 2);
            if (c.lying) {
                if (le.getPose() != Pose.SLEEPING) Compat.setPose(le, Pose.SLEEPING, true);
                ensureProxy(le, c);
            }
        }
    }

    public void releaseAll() {
        for (Map.Entry<UUID, Control> en : map.entrySet()) {
            Entity e = Bukkit.getEntity(en.getKey());
            if (e instanceof LivingEntity) {
                restore((LivingEntity) e, en.getValue());
            } else {
                removeProxy(en.getValue());
                removeCocoon(en.getValue());
            }
        }
        map.clear();
        drags.clear();
        proxies.clear();
    }
}
