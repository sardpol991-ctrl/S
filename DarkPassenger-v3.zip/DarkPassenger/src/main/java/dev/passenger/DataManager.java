package dev.passenger;

import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public final class DataManager {
    private final PassengerPlugin plugin;
    private final File file;
    private final Map<UUID, PlayerData> map = new HashMap<>();

    public DataManager(PassengerPlugin plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "data.yml");
    }

    public PlayerData get(UUID id) {
        return map.computeIfAbsent(id, PlayerData::new);
    }

    public void load() {
        YamlConfiguration y = YamlConfiguration.loadConfiguration(file);
        ConfigurationSection root = y.getConfigurationSection("players");
        if (root == null) return;
        for (String key : root.getKeys(false)) {
            UUID id;
            try {
                id = UUID.fromString(key);
            } catch (IllegalArgumentException ex) {
                continue;
            }
            ConfigurationSection s = root.getConfigurationSection(key);
            if (s == null) continue;
            PlayerData d = new PlayerData(id);
            d.dexter = s.getBoolean("dexter");
            d.marked = s.getBoolean("marked");
            d.meter = s.getDouble("meter");
            d.justified = s.getInt("justified");
            d.innocent = s.getInt("innocent");
            d.kills.addAll(s.getLongList("kills"));
            for (Map<?, ?> m : s.getMapList("slides")) {
                Object t = m.get("time");
                long time = t instanceof Number n ? n.longValue() : 0L;
                d.slides.add(new PlayerData.Slide(
                        String.valueOf(m.get("victim")),
                        time,
                        Boolean.parseBoolean(String.valueOf(m.get("justified")))));
            }
            map.put(id, d);
        }
    }

    public void save() {
        YamlConfiguration y = new YamlConfiguration();
        for (PlayerData d : map.values()) {
            if (!d.dexter && d.meter <= 0 && !d.marked && d.slides.isEmpty()
                    && d.kills.isEmpty() && d.justified == 0 && d.innocent == 0) {
                continue;
            }
            String p = "players." + d.id + ".";
            y.set(p + "dexter", d.dexter);
            y.set(p + "marked", d.marked);
            y.set(p + "meter", d.meter);
            y.set(p + "justified", d.justified);
            y.set(p + "innocent", d.innocent);
            y.set(p + "kills", new ArrayList<>(d.kills));
            List<Map<String, Object>> list = new ArrayList<>();
            for (PlayerData.Slide s : d.slides) {
                Map<String, Object> m = new LinkedHashMap<>();
                m.put("victim", s.victim());
                m.put("time", s.time());
                m.put("justified", s.justified());
                list.add(m);
            }
            y.set(p + "slides", list);
        }
        try {
            plugin.getDataFolder().mkdirs();
            y.save(file);
        } catch (IOException ex) {
            plugin.getLogger().warning("Could not save data.yml: " + ex.getMessage());
        }
    }
}
