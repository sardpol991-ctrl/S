package dev.passenger;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.Tag;
import org.bukkit.block.Block;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Mob;
import org.bukkit.entity.Monster;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.event.player.PlayerInteractAtEntityEvent;
import org.bukkit.event.player.PlayerInteractEntityEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;

import java.util.UUID;

public final class DexterListener implements Listener {
    private final PassengerPlugin plugin;

    public DexterListener(PassengerPlugin plugin) {
        this.plugin = plugin;
    }

    private boolean dexterOnly(Player p) {
        if (plugin.isDexter(p)) return true;
        plugin.messages().send(p, "not-dexter");
        return false;
    }

    private boolean canTarget(Player p, LivingEntity t) {
        Messages m = plugin.messages();
        if (t.equals(p)) return false;
        if (t instanceof Player v) {
            if (!plugin.allowsPlayers()) {
                m.send(p, "mode.no-players");
                return false;
            }
            if (v.hasPermission("dexter.immune")) {
                m.send(p, "target.immune");
                return false;
            }
            return true;
        }
        if (t instanceof Mob) {
            if (!plugin.allowsMobs()) {
                m.send(p, "mode.no-mobs");
                return false;
            }
            if (plugin.code().isExcluded(t)) {
                m.send(p, "target.excluded");
                return false;
            }
            return true;
        }
        m.send(p, "target.invalid");
        return false;
    }

    private boolean isTable(Material m) {
        return Tag.PLANKS.isTagged(m) || Tag.WOODEN_SLABS.isTagged(m);
    }

    // ---- right click in air / on block: lay on plank, bag, luminol, cleaner ----
    @EventHandler
    public void onInteract(PlayerInteractEvent e) {
        if (e.getHand() != EquipmentSlot.HAND) return;
        Action a = e.getAction();
        if (a != Action.RIGHT_CLICK_AIR && a != Action.RIGHT_CLICK_BLOCK) return;
        Player p = e.getPlayer();

        Block clicked = e.getClickedBlock();
        if (a == Action.RIGHT_CLICK_BLOCK && clicked != null
                && plugin.control().isDragging(p) && isTable(clicked.getType())) {
            e.setCancelled(true);
            if (plugin.control().layOnTable(p, clicked)) {
                plugin.messages().send(p, "table.laid");
            }
            return;
        }

        ItemStack item = e.getItem();
        ItemType t = plugin.items().typeOf(item);
        if (t == null) return;
        e.setCancelled(true);
        switch (t) {
            case BAG -> {
                if (dexterOnly(p)) plugin.ritual().disposeBag(p, item);
            }
            case LUMINOL -> useLuminol(p);
            case CLEANER -> useCleaner(p);
            default -> { }
        }
    }

    private void useLuminol(Player p) {
        Messages m = plugin.messages();
        if (!p.hasPermission("dexter.police")) {
            m.send(p, "no-permission");
            return;
        }
        int cd = plugin.getConfig().getInt("blood.luminol-cooldown-seconds", 20);
        long left = plugin.tryCooldown(p.getUniqueId(), "luminol", cd);
        if (left > 0) {
            m.send(p, "cooldown", "seconds", String.valueOf(left));
            return;
        }
        double radius = plugin.getConfig().getDouble("blood.luminol-radius", 14);
        int count = plugin.stains().nearby(p.getLocation(), radius).size();
        if (count == 0) {
            m.send(p, "luminol.none");
            return;
        }
        plugin.stains().reveal(p, radius, plugin.getConfig().getInt("blood.luminol-seconds", 8));
        m.send(p, "luminol.found", "count", String.valueOf(count));
    }

    private void useCleaner(Player p) {
        if (!dexterOnly(p)) return;
        Messages m = plugin.messages();
        long left = plugin.tryCooldown(p.getUniqueId(), "cleaner", 3);
        if (left > 0) return;
        int removed = plugin.stains().clean(p.getLocation(), plugin.getConfig().getDouble("blood.clean-radius", 4));
        if (removed == 0) m.send(p, "cleaner.none");
        else m.send(p, "cleaner.done", "count", String.valueOf(removed));
    }

    // ---- right click on entity (or on the invisible hitbox of a lying one) ----
    @EventHandler
    public void onInteractEntity(PlayerInteractEntityEvent e) {
        if (e instanceof PlayerInteractAtEntityEvent) return;
        if (e.getHand() != EquipmentSlot.HAND) return;
        Player p = e.getPlayer();
        LivingEntity target = plugin.control().resolve(e.getRightClicked());
        if (target == null) return;

        ItemStack item = p.getInventory().getItemInMainHand();
        ItemType t = plugin.items().typeOf(item);

        if (t == ItemType.SYRINGE || t == ItemType.WRAP || t == ItemType.KNIFE) {
            e.setCancelled(true);
            if (!dexterOnly(p) || !canTarget(p, target)) return;
            switch (t) {
                case SYRINGE -> syringe(p, target, item);
                case WRAP -> plugin.wraps().touch(p, target);
                case KNIFE -> knife(p, target);
                default -> { }
            }
            return;
        }

        // any other item or an empty hand: grab / release a sleeping victim
        ControlManager.Control c = plugin.control().get(target.getUniqueId());
        if (c != null && c.state == ControlManager.State.TRANQUILIZED && plugin.isDexter(p)) {
            e.setCancelled(true);
            toggleDrag(p, target, c);
        }
    }

    private void toggleDrag(Player p, LivingEntity target, ControlManager.Control c) {
        Messages m = plugin.messages();
        if (c.dragger != null) {
            if (c.dragger.equals(p.getUniqueId())) {
                plugin.control().stopDrag(p.getUniqueId());
                m.send(p, "drag.stop");
            } else {
                m.send(p, "drag.busy");
            }
            return;
        }
        if (plugin.control().isDragging(p)) {
            m.send(p, "drag.busy");
            return;
        }
        double max = plugin.getConfig().getDouble("drag.max-distance", 6.0);
        if (!p.getWorld().equals(target.getWorld()) || p.getLocation().distanceSquared(target.getLocation()) > max * max) {
            m.send(p, "drag.far");
            return;
        }
        plugin.control().startDrag(p, target);
        m.send(p, "drag.start");
    }

    private void syringe(Player p, LivingEntity target, ItemStack item) {
        Messages m = plugin.messages();
        ControlManager.Control existing = plugin.control().get(target.getUniqueId());
        if (existing != null && existing.state == ControlManager.State.BOUND) {
            m.send(p, "syringe.already");
            return;
        }
        long left = plugin.tryCooldown(p.getUniqueId(), "syringe",
                plugin.getConfig().getInt("tranquilizer.cooldown-seconds", 10));
        if (left > 0) {
            m.send(p, "cooldown", "seconds", String.valueOf(left));
            return;
        }
        if (plugin.getConfig().getBoolean("tranquilizer.consume", true)) {
            item.setAmount(item.getAmount() - 1);
        }
        Runnable impact = () -> {
            if (!target.isValid()) return;
            plugin.control().tranquilize(target, p.getUniqueId(),
                    plugin.getConfig().getInt("tranquilizer.sleep-seconds", 60));
            target.getWorld().playSound(target.getLocation(), Sound.ENTITY_ARROW_HIT_PLAYER, 1f, 0.8f);
            m.send(p, "syringe.hit", "target", plugin.ritual().nameOf(target));
            if (target instanceof Player v) m.send(v, "syringe.victim");
        };
        if (plugin.animations().enabled()) {
            plugin.animations().syringe(p, target, plugin.items().displayStack(ItemType.SYRINGE), impact);
        } else {
            impact.run();
        }
    }

    private void knife(Player p, LivingEntity target) {
        ControlManager.Control c = plugin.control().get(target.getUniqueId());
        if (c == null || c.state != ControlManager.State.BOUND) {
            plugin.messages().send(p, "ritual.need-bound");
            return;
        }
        plugin.ritual().perform(p, target);
    }

    // ---- combat tracking for the meter ----
    @EventHandler(ignoreCancelled = true)
    public void onDamageBy(EntityDamageByEntityEvent e) {
        if (e.getDamager() instanceof Player p && e.getEntity() instanceof LivingEntity && plugin.isDexter(p)) {
            plugin.passenger().markCombat(p);
        }
    }

    // ---- deaths: ritual completion, murder tracking, kill gain ----
    @EventHandler(priority = EventPriority.MONITOR)
    public void onDeath(EntityDeathEvent e) {
        LivingEntity victim = e.getEntity();
        if (victim instanceof Player dead) plugin.control().stopDrag(dead.getUniqueId());
        plugin.control().release(victim);
        UUID dexterId = plugin.ritual().takePending(victim.getUniqueId());
        if (dexterId != null) {
            Player d = Bukkit.getPlayer(dexterId);
            if (d != null) plugin.ritual().complete(d, victim);
            return;
        }
        Player killer = victim.getKiller();
        if (killer == null || killer.equals(victim)) return;
        if (victim instanceof Player) {
            plugin.code().recordKill(killer);
        } else if (victim instanceof Monster && plugin.isDexter(killer)) {
            plugin.passenger().addMeter(killer, plugin.getConfig().getDouble("passenger.kill-gain", 3.0));
        }
    }
}
