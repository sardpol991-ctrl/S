package dev.passenger;

import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.World;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;

public final class StainManager {
    public record Stain(UUID world, double x, double y, double z, long time) {}

    private final PassengerPlugin plugin;
    private final File file;
    private final List<Stain> stains = new ArrayList<>();

    public StainManager(PassengerPlugin plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "stains.yml");
    }

    public void load() {
        YamlConfiguration y = YamlConfiguration.loadConfiguration(file);
        for (String line : y.getStringList("stains")) {
            String[] p = line.split(";");
            if (p.length != 5) continue;
            try {
                stains.add(new Stain(UUID.fromString(p[0]), Double.parseDouble(p[1]), Double.parseDouble(p[2]),
                        Double.parseDouble(p[3]), Long.parseLong(p[4])));
            } catch (IllegalArgumentException ignored) {
                // skip broken line
            }
        }
        purge();
    }

    public void save() {
        purge();
        YamlConfiguration y = new YamlConfiguration();
        List<String> out = new ArrayList<>();
        for (Stain s : stains) {
            out.add(s.world() + ";" + s.x() + ";" + s.y() + ";" + s.z() + ";" + s.time());
        }
        y.set("stains", out);
        try {
            plugin.getDataFolder().mkdirs();
            y.save(file);
        } catch (IOException ex) {
            plugin.getLogger().warning("Could not save stains.yml: " + ex.getMessage());
        }
    }

    public void add(Location base, int count) {
        World w = base.getWorld();
        if (w == null) return;
        ThreadLocalRandom r = ThreadLocalRandom.current();
        long now = System.currentTimeMillis();
        for (int i = 0; i < count; i++) {
            Location l = base.clone().add(r.nextDouble(-1.2, 1.2), 0, r.nextDouble(-1.2, 1.2));
            for (int d = 0; d < 4 && !l.clone().subtract(0, 1, 0).getBlock().getType().isSolid(); d++) {
                l.subtract(0, 1, 0);
            }
            double y = l.getBlockY() + 0.05;
            stains.add(new Stain(w.getUID(), l.getX(), y, l.getZ(), now));
            w.spawnParticle(Particle.DUST, new Location(w, l.getX(), y, l.getZ()), 8, 0.3, 0.05, 0.3, 0,
                    new Particle.DustOptions(Color.RED, 1.5f));
        }
    }

    public void purge() {
        long life = plugin.getConfig().getLong("blood.lifetime-minutes", 30) * 60_000L;
        long now = System.currentTimeMillis();
        stains.removeIf(s -> now - s.time() > life);
    }

    public List<Stain> nearby(Location loc, double radius) {
        List<Stain> out = new ArrayList<>();
        World w = loc.getWorld();
        if (w == null) return out;
        double r2 = radius * radius;
        for (Stain s : stains) {
            if (!s.world().equals(w.getUID())) continue;
            double dx = s.x() - loc.getX();
            double dy = s.y() - loc.getY();
            double dz = s.z() - loc.getZ();
            if (dx * dx + dy * dy + dz * dz <= r2) out.add(s);
        }
        return out;
    }

    public int clean(Location loc, double radius) {
        List<Stain> near = nearby(loc, radius);
        stains.removeAll(near);
        return near.size();
    }

    public void reveal(Player p, double radius, int seconds) {
        final int max = seconds * 5;
        final int[] ticks = {0};
        new BukkitRunnable() {
            @Override
            public void run() {
                if (!p.isOnline() || ticks[0]++ >= max) {
                    cancel();
                    return;
                }
                for (Stain s : nearby(p.getLocation(), radius)) {
                    p.spawnParticle(Particle.DUST, new Location(p.getWorld(), s.x(), s.y(), s.z()), 3, 0.2, 0.02, 0.2, 0,
                            new Particle.DustOptions(Color.fromRGB(60, 180, 255), 1.4f));
                }
            }
        }.runTaskTimer(plugin, 0L, 4L);
    }
}
