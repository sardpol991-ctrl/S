package dev.passenger;

import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.util.Vector;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.UUID;

/** Wrapping takes time and only progresses while the dexter keeps holding right click. */
public final class WrapManager {
    private static final class Session {
        UUID victim;
        int ticks;
        long lastTouch;
    }

    private final PassengerPlugin plugin;
    private final Map<UUID, Session> sessions = new HashMap<>();

    public WrapManager(PassengerPlugin plugin) {
        this.plugin = plugin;
    }

    /** Called on every right click on the victim while holding the film. */
    public void touch(Player d, LivingEntity v) {
        Messages m = plugin.messages();
        ControlManager.Control c = plugin.control().get(v.getUniqueId());
        if (c == null || c.state != ControlManager.State.TRANQUILIZED) {
            d.sendActionBar(m.component("wrap.need-tranq"));
            return;
        }
        if (plugin.getConfig().getBoolean("wrap.require-table", true) && c.table == null) {
            d.sendActionBar(m.component("wrap.need-table"));
            return;
        }
        Session s = sessions.get(d.getUniqueId());
        if (s == null || !s.victim.equals(v.getUniqueId())) {
            s = new Session();
            s.victim = v.getUniqueId();
            sessions.put(d.getUniqueId(), s);
        }
        s.lastTouch = System.currentTimeMillis();
    }

    /** Runs every 2 ticks. */
    public void tick() {
        if (sessions.isEmpty()) return;
        Messages m = plugin.messages();
        long now = System.currentTimeMillis();
        int need = Math.max(20, plugin.getConfig().getInt("wrap.duration-seconds", 6) * 20);
        Iterator<Map.Entry<UUID, Session>> it = sessions.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<UUID, Session> en = it.next();
            Session s = en.getValue();
            Player d = Bukkit.getPlayer(en.getKey());
            Entity ve = Bukkit.getEntity(s.victim);
            ControlManager.Control c = plugin.control().get(s.victim);
            boolean released = now - s.lastTouch > 600L;
            boolean ok = d != null && ve instanceof LivingEntity && c != null
                    && c.state == ControlManager.State.TRANQUILIZED
                    && plugin.items().typeOf(d.getInventory().getItemInMainHand()) == ItemType.WRAP
                    && d.getWorld().equals(ve.getWorld())
                    && d.getLocation().distanceSquared(ve.getLocation()) <= 36.0;
            if (!ok || released) {
                if (d != null && s.ticks > 0) {
                    d.sendActionBar(m.component(released ? "wrap.interrupted" : "wrap.failed"));
                }
                it.remove();
                continue;
            }
            LivingEntity v = (LivingEntity) ve;
            s.ticks += 2;
            double progress = Math.min(1.0, s.ticks / (double) need);
            int filled = (int) Math.round(progress * 20);
            d.sendActionBar(m.component("wrap.progress",
                    "filled", "█".repeat(filled),
                    "empty", "░".repeat(20 - filled),
                    "percent", String.valueOf(Math.round(progress * 100))));
            spiral(v, progress, s.ticks);
            if (s.ticks % 10 == 0) {
                v.getWorld().playSound(v.getLocation(), Sound.ITEM_ARMOR_EQUIP_LEATHER, 0.8f, 1.6f);
            }
            if (s.ticks >= need) {
                finish(d, v);
                it.remove();
            }
        }
    }

    private void finish(Player d, LivingEntity v) {
        Messages m = plugin.messages();
        int secs = plugin.getConfig().getInt("wrap.bind-seconds", 30);
        if (!plugin.control().wrap(v, d.getUniqueId(), secs)) return;
        ItemStack hand = d.getInventory().getItemInMainHand();
        if (plugin.getConfig().getBoolean("wrap.consume", true)) {
            hand.setAmount(hand.getAmount() - 1);
        }
        v.getWorld().playSound(v.getLocation(), Sound.BLOCK_WOOL_PLACE, 1f, 0.8f);
        d.sendActionBar(Component.empty());
        m.send(d, "wrap.done", "target", plugin.ritual().nameOf(v));
        if (v instanceof Player victim) m.send(victim, "wrap.victim");
    }

    /** Ring of particles that travels along the body while wrapping. */
    private void spiral(LivingEntity v, double progress, int ticks) {
        ControlManager.Control c = plugin.control().get(v.getUniqueId());
        if (c == null) return;
        Vector h = plugin.control().headVector(v);
        Vector n = new Vector(-h.getZ(), 0, h.getX());
        double along = progress * c.standingHeight;
        Location ring = v.getLocation().add(h.clone().multiply(along)).add(0, 0.2, 0);
        Particle.DustOptions dust = new Particle.DustOptions(Color.fromRGB(225, 240, 250), 1.2f);
        for (int i = 0; i < 6; i++) {
            double a = ticks * 0.6 + i * Math.PI / 3.0;
            Vector off = n.clone().multiply(Math.cos(a) * 0.45).add(new Vector(0, Math.sin(a) * 0.3 + 0.1, 0));
            v.getWorld().spawnParticle(Particle.DUST, ring.clone().add(off), 1, 0, 0, 0, 0, dust);
        }
    }
}
