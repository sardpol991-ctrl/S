package dev.passenger;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.List;
import java.util.UUID;

public final class SlidesGui implements Listener {
    private static final int PER_PAGE = 45;

    public static final class Holder implements InventoryHolder {
        public final UUID owner;
        public final String ownerName;
        public final int page;
        private Inventory inventory;

        Holder(UUID owner, String ownerName, int page) {
            this.owner = owner;
            this.ownerName = ownerName;
            this.page = page;
        }

        void bind(Inventory inv) {
            this.inventory = inv;
        }

        @Override
        public Inventory getInventory() {
            return inventory;
        }
    }

    private final PassengerPlugin plugin;

    public SlidesGui(PassengerPlugin plugin) {
        this.plugin = plugin;
    }

    public void open(Player viewer, UUID owner, String ownerName, int page) {
        PlayerData pd = plugin.data().get(owner);
        int pages = Math.max(1, (pd.slides.size() + PER_PAGE - 1) / PER_PAGE);
        int pg = Math.max(0, Math.min(page, pages - 1));
        Messages m = plugin.messages();
        Holder holder = new Holder(owner, ownerName, pg);
        Inventory inv = Bukkit.createInventory(holder, 54,
                m.component("gui.title", "player", ownerName, "page", String.valueOf(pg + 1)));
        holder.bind(inv);

        int from = pg * PER_PAGE;
        int to = Math.min(pd.slides.size(), from + PER_PAGE);
        for (int i = from; i < to; i++) {
            inv.setItem(i - from, plugin.items().slideItem(pd.slides.get(i), i + 1));
        }
        if (pg > 0) inv.setItem(45, named(Material.ARROW, m.component("gui.prev")));
        if (pg < pages - 1) inv.setItem(53, named(Material.ARROW, m.component("gui.next")));

        ItemStack info = named(Material.PAPER, m.component("gui.info.name"));
        ItemMeta meta = info.getItemMeta();
        List<Component> lore = m.list("gui.info.lore",
                "slides", String.valueOf(pd.slides.size()),
                "justified", String.valueOf(pd.justified),
                "innocent", String.valueOf(pd.innocent));
        meta.lore(lore);
        info.setItemMeta(meta);
        inv.setItem(49, info);

        viewer.openInventory(inv);
    }

    private ItemStack named(Material mat, Component name) {
        ItemStack s = new ItemStack(mat);
        ItemMeta meta = s.getItemMeta();
        meta.displayName(name.decoration(TextDecoration.ITALIC, false));
        s.setItemMeta(meta);
        return s;
    }

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        if (!(e.getInventory().getHolder() instanceof Holder h)) return;
        e.setCancelled(true);
        if (!(e.getWhoClicked() instanceof Player p)) return;
        if (!e.getInventory().equals(e.getClickedInventory())) return;
        ItemStack clicked = e.getCurrentItem();
        if (clicked == null || clicked.getType() != Material.ARROW) return;
        int slot = e.getRawSlot();
        int newPage;
        if (slot == 45) newPage = h.page - 1;
        else if (slot == 53) newPage = h.page + 1;
        else return;
        Bukkit.getScheduler().runTask(plugin, () -> open(p, h.owner, h.ownerName, newPage));
    }

    @EventHandler
    public void onDrag(InventoryDragEvent e) {
        if (e.getInventory().getHolder() instanceof Holder) e.setCancelled(true);
    }
}
