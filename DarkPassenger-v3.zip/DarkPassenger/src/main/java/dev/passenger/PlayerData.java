package dev.passenger;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public final class PlayerData {
    public record Slide(String victim, long time, boolean justified) {}

    public final UUID id;
    public boolean dexter;
    public boolean marked;
    public double meter;
    public int justified;
    public int innocent;
    public final List<Slide> slides = new ArrayList<>();
    public final List<Long> kills = new ArrayList<>();

    public PlayerData(UUID id) {
        this.id = id;
    }
}
