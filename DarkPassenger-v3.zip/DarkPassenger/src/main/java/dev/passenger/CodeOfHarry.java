package dev.passenger;

import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Tameable;

public final class CodeOfHarry {
    public enum Verdict { GUILTY, INNOCENT, NEUTRAL }

    private final PassengerPlugin plugin;

    public CodeOfHarry(PassengerPlugin plugin) {
        this.plugin = plugin;
    }

    public Verdict judge(LivingEntity v) {
        if (v instanceof Player p) {
            PlayerData d = plugin.data().get(p.getUniqueId());
            if (d.marked) return Verdict.GUILTY;
            int threshold = plugin.getConfig().getInt("code.pvp.guilty-kills-threshold", 3);
            return recentKills(d) >= threshold ? Verdict.GUILTY : Verdict.INNOCENT;
        }
        String type = v.getType().name();
        if (plugin.getConfig().getStringList("code.guilty-mobs").contains(type)) return Verdict.GUILTY;
        if (v instanceof Tameable t && t.isTamed()) return Verdict.INNOCENT;
        if (plugin.getConfig().getStringList("code.innocent-mobs").contains(type)) return Verdict.INNOCENT;
        return Verdict.NEUTRAL;
    }

    public int recentKills(PlayerData d) {
        long window = plugin.getConfig().getLong("code.pvp.kills-window-minutes", 60) * 60_000L;
        long cutoff = System.currentTimeMillis() - window;
        d.kills.removeIf(t -> t < cutoff);
        return d.kills.size();
    }

    public void recordKill(Player killer) {
        PlayerData d = plugin.data().get(killer.getUniqueId());
        d.kills.add(System.currentTimeMillis());
        recentKills(d);
    }

    public boolean isExcluded(Entity e) {
        return plugin.getConfig().getStringList("code.excluded-mobs").contains(e.getType().name());
    }
}
