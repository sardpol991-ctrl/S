package dev.passenger;

import org.bukkit.Material;

public enum ItemType {
    SYRINGE("syringe", Material.BLAZE_ROD),
    WRAP("wrap", Material.PHANTOM_MEMBRANE),
    KNIFE("knife", Material.IRON_SWORD),
    BAG("bag", Material.LEATHER),
    LUMINOL("luminol", Material.GLOW_INK_SAC),
    CLEANER("cleaner", Material.BRUSH);

    public final String key;
    public final Material def;

    ItemType(String key, Material def) {
        this.key = key;
        this.def = def;
    }

    public static ItemType fromKey(String s) {
        for (ItemType t : values()) {
            if (t.key.equalsIgnoreCase(s)) return t;
        }
        return null;
    }
}
